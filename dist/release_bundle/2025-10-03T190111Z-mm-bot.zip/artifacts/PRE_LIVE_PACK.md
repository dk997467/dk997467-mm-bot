PRE-LIVE DRY RUN PACK

Result: FAIL

| step | ok | details |
|------|----|---------|
| bug_bash | OK | skipped |
| autopilot_dry | OK | AUTOPILOT=OK |
| daily_check | FAIL | {"daily_check":"GREEN","issues":[]} |
| edge_sentinel | FAIL | analyze.py: error: unrecognized arguments: --out-json artifacts/EDGE_SENTINEL.json |
| param_sweep | FAIL | FileNotFoundError: [Errno 2] No such file or directory: 'tests/fixtures/sweep/events_case1.jsonl' |
| apply_from_sweep | OK | TUNING WROTE artifacts/TUNING_REPORT.json tools/tuning/overlay_profile.yaml |
| chaos_failover_dry | OK | CHAOS_RESULT=OK |
| rotate_artifacts_dry | FAIL | MemoryError |
| scan_secrets | FAIL |  |
