# SOAK TEST RESULTS

## Summary

**Verdict:** ✅ PASS
**Duration:** 72 hours

## Key Metrics

| Metric | Value |
|--------|-------|
| Latency P95 | 142.5 ms |
| Hit Ratio | 78.00% |
| Deadline Miss Rate | 1.50% |
| Edge BPS (24h EMA) | 2.60 |
| Maker Share | 92.00% |
| WS Lag Max | 125.0 ms |

## Gates

| Gate | Threshold | Actual | Status | Severity |
|------|-----------|--------|--------|----------|
| latency_p95 | 150.0 | 142.5000 | ✅ PASS | hard |
| hit_ratio | 0.7 | 0.7800 | ✅ PASS | hard |
| deadline_miss_rate | 0.02 | 0.0150 | ✅ PASS | hard |
| edge_bps | 2.0 | 2.6000 | ✅ PASS | hard |
| maker_share | 0.85 | 0.9200 | ✅ PASS | soft |
| ws_lag | 200.0 | 125.0000 | ✅ PASS | soft |

## Decision

✅ **All hard gates passed.** System is stable for production.
