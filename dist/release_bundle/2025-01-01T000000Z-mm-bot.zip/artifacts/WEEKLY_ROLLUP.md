WEEKLY SOAK ROLLUP

| metric | v1 | v2 | v3 |
|--------|----|----|----|
| edge_net_bps | 2.800000 | 2.700000 | 2.850000 |
| order_age_p95_ms | 305.000000 | 320.000000 |  |
| taker_share_pct | 12.500000 | 14.000000 |  |
| ledger_equity_change_eur | 0.500000 | fees=0.600000 | rebates=-0.300000 |

Verdict: GO
