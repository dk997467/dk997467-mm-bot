READINESS SCORE

Result: NO-GO  Score: 60.000000

| section | score |
|---------|-------|
| edge | 0.000000 |
| latency | 25.000000 |
| taker | 15.000000 |
| guards | 0.000000 |
| chaos | 10.000000 |
| tests | 10.000000 |
