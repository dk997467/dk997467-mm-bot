READINESS SCORE

Result: GO  Score: 100.000000

| section | score |
|---------|-------|
| edge | 30.000000 |
| latency | 25.000000 |
| taker | 15.000000 |
| guards | 10.000000 |
| chaos | 10.000000 |
| tests | 10.000000 |
