Documentation Index
==================

## Core Documentation

- [RUNBOOKS.md](RUNBOOKS.md) - Operational procedures and release route
- [GO_CHECKLIST.md](GO_CHECKLIST.md) - Pre-release validation checklist
- [REPORTS.md](REPORTS.md) - Report formats and locations

## Reports

- [REPORT_EDGE.md](../REPORT_EDGE.md) - Edge audit components and structure
- [REPORT_RECONCILE.md](../REPORT_RECONCILE.md) - FinOps reconciliation fields
- [REPORT_CANARY.md](REPORT_CANARY.md) - Canary deployment reports
- [REPORT_SIM.md](REPORT_SIM.md) - Live simulation reports  
- [REPORT_BACKTEST.md](REPORT_BACKTEST.md) - Backtest analysis reports

## Specialized Topics

- [EXCHANGE_CONNECTIVITY.md](EXCHANGE_CONNECTIVITY.md) - Exchange integration
- [INVESTOR_DECK.md](INVESTOR_DECK.md) - Investor package generation
- [SOP_CAPITAL.md](SOP_CAPITAL.md) - Capital management procedures
- [research_pipeline.md](research_pipeline.md) - Research workflow

## Quick Reference

- [README.md](../README.md) - Main project overview and quickstart
- [CHANGELOG.md](../CHANGELOG.md) - Release notes and changes
